#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "Graph.h"

#define STD_BUF_SIZE 10

// Function declarations
bool isSameStr(char *, char *);
bool differByOne(char *, char *);
char* readFromStdin(void);
int splitToWords(char *);

// Global variables
char* words[20];
int numberOfWords=0;

int main(void)
{
    // get words from stdin
    char* inputStr = readFromStdin();
    numberOfWords = splitToWords(inputStr);

    // print dictionary
    printf("Dictionary\n");
    for(int i =0;i<numberOfWords;i++)
        printf("%d: %s\n",i,words[i]);

    // build new graph
    Graph graph = newGraph(numberOfWords);
    for(int i=0;i<numberOfWords;i++)
    {
        for(int j=i+1;j<numberOfWords;j++)
        {
            // printf("word %d: %s | word %d: %s diff by one?%d\n",i,words[i],j,words[j],differByOne(words[i],words[j]));
            if(differByOne(words[i],words[j]))
            {
                Edge edge = newEdge(i,j);
                insertEdge(edge,graph);
            }
        }
    }
    printf("Ordered Word Ladder Graph\n");
    showGraph(graph);
    freeGraph(graph);
}

#pragma region Handle Stdin
char* readFromStdin()
{
    char thisChar;
    char* strBufferPtr = (char*)malloc(STD_BUF_SIZE);
    int actualBufferSize = STD_BUF_SIZE;
    int bufferCnt = 0; // buffer counter
    char* resultStr;

    thisChar = getchar();
    while(thisChar!=EOF)
    {
        if(bufferCnt >= actualBufferSize-2)
        {
            actualBufferSize += STD_BUF_SIZE;
            strBufferPtr = realloc(strBufferPtr,actualBufferSize);
            if(strBufferPtr==NULL)
            {
                fprintf(stderr, "Memory Error.\n");
                exit(1);
            }
        }

        *(strBufferPtr+bufferCnt) = thisChar;
        bufferCnt++;
        thisChar = getchar();   
    }

    resultStr = strBufferPtr;
    
    free(strBufferPtr);
    strBufferPtr = NULL;

    return resultStr;
}

//todo: handle duplicates
int splitToWords(char* inputStr)
{
    const char* delim = " \t\n\r";
    char* thisWord;
    int index=0;

    thisWord = strtok(inputStr,delim);
    while(thisWord != NULL)
    {
        // check duplication
        bool sameStrFound = false;
        for(int i=0;i<index;i++)
        {
            sameStrFound = isSameStr(thisWord,words[i])?true:false;
            if(sameStrFound)
                break;
        }

        if(!sameStrFound)
            words[index++] = thisWord;
        
        thisWord = strtok(NULL,delim);
    }

    return index;
}
#pragma endregion

#pragma region String Compare
bool isSameStr(char * str1, char * str2)
{
    if(strlen(str1)!=strlen(str2))
        return false;
    
    for(int i=0;i<strlen(str1);i++)
    {
        if (*(str1+i) != *(str2+i))
            return false;
    }

    return true;
}

bool differByOne(char * str1, char * str2)
{
    int len1 = (int)strlen(str1);
    int len2 = (int)strlen(str2);
    int diffCnt;
    
    // Secnario 1: Length difference too big, no need to compare
    if (abs(len1 - len2)>1)
        return false;
    
    // Senario 2: Length is equal, compare character by character
    if (len1 == len2)
    {
        diffCnt = 0;
        for(int i=0;i<len1;i++)
        {
            if(*(str1+i) != *(str2+i))
                diffCnt++;
        }
        
        return diffCnt==1?true:false;
    }
    
    // Scenario 3: length difference is one, compare shorter str to longer str
    if (abs(len1-len2)==1)
    {
        char * shortStr,* longStr;
        int shortLen, longLen;
        
        shortStr = len1>len2?str2:str1;
        longStr = len1>len2?str1:str2;
        shortLen = len1>len2?len2:len1;
        longLen = len1>len2?len1:len2;
        
        diffCnt = 0;
        int shortIndex = 0;
        int longIndex = 0;
        while(shortIndex <= (shortLen-1) && longIndex <= (longLen-1))
        {
            if(*(shortStr+shortIndex)!=*(longStr+longIndex))
            {
                diffCnt++;
                longIndex++;
            }
            else
            {
                shortIndex++;
                longIndex++;
            }
        }
        
        return diffCnt>1?false:true;
    }
    
    return false; // catch all
}
#pragma endregion