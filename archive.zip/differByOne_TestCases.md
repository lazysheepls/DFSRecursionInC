True:
in
ion
 
False:
ai
ion
 
True:
in
bin

True:
don
on

True:
pank
pan

True:
pank
ank

True:
pank
pak

False:
pank
pnr

True:
pank
park
 
False:
no
don
 
False:
are
rea